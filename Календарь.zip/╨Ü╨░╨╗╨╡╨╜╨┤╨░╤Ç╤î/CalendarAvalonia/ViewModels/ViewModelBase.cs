﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace CalendarAvalonia.ViewModels;

public class ViewModelBase : ObservableObject
{
}
