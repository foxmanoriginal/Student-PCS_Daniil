using System;
using System.Windows.Forms;

namespace CalendarApp
{
    public class MainWindow : Form
    {
        public MainWindow()
        {
            this.Text = "Календарь";
            this.Width = 800;
            this.Height = 600;
        }
    }
}
