#!/bin/zsh
# Скрипт для запуска календаря Avalonia
cd "$(dirname "$0")/CalendarAvalonia"
dotnet run
